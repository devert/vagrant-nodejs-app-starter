## v1.0.4:

* [COOK-1623] - add attribute to prevent erlang installation
* [COOK-1627] - set attributes at default precedence instead of normal (set)

## v1.0.2:

* [COOK-1399] - make bind address an attribute

## v1.0.0:

* create group for couchdb
